package com.architectcoders.aacboard.network

const val ARASAAC_BASE_URL = "https://api.arasaac.org/api/"