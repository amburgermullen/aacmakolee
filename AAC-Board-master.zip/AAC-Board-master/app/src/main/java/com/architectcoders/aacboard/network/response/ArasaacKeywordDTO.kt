package com.architectcoders.aacboard.network.response

data class ArasaacKeywordDTO(val keyword: String)