package com.architectcoders.aacboard.domain.data.cell

data class CellPictogram(
    val keyword: String,
    val url: String,
)